var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};return e[n].call(o.exports,o,o.exports,r),o.l=!0,o.exports}return r.m=e,r.c=t,r.d=function(e,t,n){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(e,t){if(1&t&&(e=r(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(r.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)r.d(n,o,function(t){return e[t]}.bind(null,o));return n},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s=0)}([
/*!******************************!*\
  !*** ./Diagnostics/index.ts ***!
  \******************************/
/*! no static exports found */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=function(){function e(){}return e.prototype.init=function(e,t,r,n){this.lastMessage="",this.updateView(e)},e.prototype.updateView=function(e){this.lastMessage!=e.parameters.log.raw&&(this.lastMessage,console.log(e.parameters.log.raw))},e.prototype.getOutputs=function(){return{}},e.prototype.destroy=function(){},e}();t.Diagnostics=n}]);
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PowerTools.Diagnostics', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Diagnostics);
} else {
	var PowerTools = PowerTools || {};
	PowerTools.Diagnostics = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Diagnostics;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}