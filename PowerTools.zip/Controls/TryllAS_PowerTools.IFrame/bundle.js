var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};return e[n].call(o.exports,o,o.exports,r),o.l=!0,o.exports}return r.m=e,r.c=t,r.d=function(e,t,n){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(e,t){if(1&t&&(e=r(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(r.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)r.d(n,o,function(t){return e[t]}.bind(null,o));return n},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s=0)}([
/*!*************************!*\
  !*** ./IFrame/index.ts ***!
  \*************************/
/*! no static exports found */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=function(){function e(){}return e.prototype.init=function(e,t,r,n){this.iframe=document.createElement("iframe"),this.options={src:"http://blanks",width:"500px",height:"500px",sandbox:"allow-scripts allow-same-origin allow-top-navigation allow-forms allow-popups allow-pointer-lock allow-popups-to-escape-sandbox",style:"border:0;padding:0;margin:0;"},this.updateView(e),n.appendChild(this.iframe)},e.prototype.changeIfDifferent=function(e,t,r){e.getAttribute(t)!=r&&(console.log("Updating "+t+" "+r),e.setAttribute(t,r))},e.prototype.updateView=function(e){var t={},r=this;Object.assign(t,e.parameters),Object.keys(this.options).forEach((function(e){t["iframe_"+e]&&t["iframe_"+e].raw?r.changeIfDifferent(r.iframe,e,t["iframe_"+e].raw):r.changeIfDifferent(r.iframe,e,r.options[e])}))},e.prototype.getOutputs=function(){return{}},e.prototype.destroy=function(){},e}();t.IFrame=n}]);
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PowerTools.IFrame', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IFrame);
} else {
	var PowerTools = PowerTools || {};
	PowerTools.IFrame = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IFrame;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}